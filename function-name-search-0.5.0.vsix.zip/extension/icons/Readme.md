Image Properties:-
1000x1000 pixel
.svg