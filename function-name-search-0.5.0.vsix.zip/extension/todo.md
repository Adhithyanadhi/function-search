write a test suite
test fallback mechanism